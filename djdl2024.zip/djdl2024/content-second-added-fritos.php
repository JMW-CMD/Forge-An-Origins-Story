<?php
/**
 * The Navigation for our theme
 *
 * This is the template that displays all of the website code from <body> up until </nav>
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Forge: An Origins Story
 */
?>

TEXT FROM 'CONTENT-SECOND-ADDED-FRITOS' TEMPLATE