<?php
/**
 * The hero section for pages
 *
 * This is the template that displays all of the website code from <header> up until </header>
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Forge: An Origins Story
 */
?>

TEXT FROM 'HERO-PAGE' TEMPLATE
