<?php
/**
 * The content template for pages
 *
 * This is the template that displays all of the website code from <main> up until </main>
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Forge: An Origins Story
 */
?>
TEXT FROM 'CONTENT-PAGE' TEMPLATE